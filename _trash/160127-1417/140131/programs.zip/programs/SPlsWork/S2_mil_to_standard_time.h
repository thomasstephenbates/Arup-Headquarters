#ifndef __S2_MIL_TO_STANDARD_TIME_H__
#define __S2_MIL_TO_STANDARD_TIME_H__




/*
* Constructor and Destructor
*/

/*
* DIGITAL_INPUT
*/
#define __S2_mil_to_standard_time_SHOW_TIME_DIG_INPUT 0


/*
* ANALOG_INPUT
*/
#define __S2_mil_to_standard_time_HOUR_IN_ANALOG_INPUT 0
#define __S2_mil_to_standard_time_MINUTE_IN_ANALOG_INPUT 1




/*
* DIGITAL_OUTPUT
*/


/*
* ANALOG_OUTPUT
*/

#define __S2_mil_to_standard_time_FORMATTED_TIME$_STRING_OUTPUT 0


/*
* Direct Socket Variables
*/




/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* STRING_PARAMETER
*/


/*
* INTEGER
*/


/*
* LONG_INTEGER
*/


/*
* SIGNED_INTEGER
*/


/*
* SIGNED_LONG_INTEGER
*/


/*
* STRING
*/
#define __S2_mil_to_standard_time_TEMPHOUR_STRING_MAX_LEN 2
CREATE_STRING_STRUCT( S2_mil_to_standard_time, __TEMPHOUR, __S2_mil_to_standard_time_TEMPHOUR_STRING_MAX_LEN );
#define __S2_mil_to_standard_time_TEMPMINUTE_STRING_MAX_LEN 2
CREATE_STRING_STRUCT( S2_mil_to_standard_time, __TEMPMINUTE, __S2_mil_to_standard_time_TEMPMINUTE_STRING_MAX_LEN );
#define __S2_mil_to_standard_time_TEMPTOD_STRING_MAX_LEN 2
CREATE_STRING_STRUCT( S2_mil_to_standard_time, __TEMPTOD, __S2_mil_to_standard_time_TEMPTOD_STRING_MAX_LEN );
#define __S2_mil_to_standard_time_TEMPTIME_STRING_MAX_LEN 8
CREATE_STRING_STRUCT( S2_mil_to_standard_time, __TEMPTIME, __S2_mil_to_standard_time_TEMPTIME_STRING_MAX_LEN );

/*
* STRUCTURE
*/

START_GLOBAL_VAR_STRUCT( S2_mil_to_standard_time )
{
   void* InstancePtr;
   struct GenericOutputString_s sGenericOutStr;
   unsigned short LastModifiedArrayIndex;

   DECLARE_STRING_STRUCT( S2_mil_to_standard_time, __TEMPHOUR );
   DECLARE_STRING_STRUCT( S2_mil_to_standard_time, __TEMPMINUTE );
   DECLARE_STRING_STRUCT( S2_mil_to_standard_time, __TEMPTOD );
   DECLARE_STRING_STRUCT( S2_mil_to_standard_time, __TEMPTIME );
};

START_NVRAM_VAR_STRUCT( S2_mil_to_standard_time )
{
};



#endif //__S2_MIL_TO_STANDARD_TIME_H__

