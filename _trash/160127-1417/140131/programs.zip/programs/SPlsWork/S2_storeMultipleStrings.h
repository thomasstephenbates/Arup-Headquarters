#ifndef __S2_STOREMULTIPLESTRINGS_H__
#define __S2_STOREMULTIPLESTRINGS_H__




/*
* Constructor and Destructor
*/

/*
* DIGITAL_INPUT
*/
#define __S2_storeMultipleStrings_STORE_DIG_INPUT 0
#define __S2_storeMultipleStrings_RECALL_DIG_INPUT 1
#define __S2_storeMultipleStrings_RECALL_ALL_DIG_INPUT 2

#define __S2_storeMultipleStrings_WHICHSTRINGTOSTORE_DIG_INPUT 3
#define __S2_storeMultipleStrings_WHICHSTRINGTOSTORE_ARRAY_LENGTH 20

/*
* ANALOG_INPUT
*/

#define __S2_storeMultipleStrings_STRINGINPUT_STRING_INPUT 0
#define __S2_storeMultipleStrings_STRINGINPUT_STRING_MAX_LEN 200
CREATE_STRING_STRUCT( S2_storeMultipleStrings, __STRINGINPUT, __S2_storeMultipleStrings_STRINGINPUT_STRING_MAX_LEN );



/*
* DIGITAL_OUTPUT
*/


/*
* ANALOG_OUTPUT
*/


#define __S2_storeMultipleStrings_STRINGOUTPUT_STRING_OUTPUT 0
#define __S2_storeMultipleStrings_STRINGOUTPUT_ARRAY_LENGTH 20

/*
* Direct Socket Variables
*/




/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* STRING_PARAMETER
*/


/*
* INTEGER
*/
CREATE_INTARRAY1D( S2_storeMultipleStrings, __INPUTSTATE, 19 );;


/*
* LONG_INTEGER
*/


/*
* SIGNED_INTEGER
*/


/*
* SIGNED_LONG_INTEGER
*/


/*
* STRING
*/
#define __S2_storeMultipleStrings_STRINGTOSTORE_STRING_MAX_LEN 200
CREATE_STRING_STRUCT( S2_storeMultipleStrings, __STRINGTOSTORE, __S2_storeMultipleStrings_STRINGTOSTORE_STRING_MAX_LEN );
#define __S2_storeMultipleStrings_STOREDSTRINGS_ARRAY_NUM_ELEMS 19
#define __S2_storeMultipleStrings_STOREDSTRINGS_ARRAY_NUM_CHARS 200
CREATE_STRING_ARRAY( S2_storeMultipleStrings, __STOREDSTRINGS, __S2_storeMultipleStrings_STOREDSTRINGS_ARRAY_NUM_ELEMS, __S2_storeMultipleStrings_STOREDSTRINGS_ARRAY_NUM_CHARS );

/*
* STRUCTURE
*/

START_GLOBAL_VAR_STRUCT( S2_storeMultipleStrings )
{
   void* InstancePtr;
   struct GenericOutputString_s sGenericOutStr;
   unsigned short LastModifiedArrayIndex;

   DECLARE_IO_ARRAY( __WHICHSTRINGTOSTORE );
   DECLARE_IO_ARRAY( __STRINGOUTPUT );
   DECLARE_STRING_STRUCT( S2_storeMultipleStrings, __STRINGINPUT );
};

START_NVRAM_VAR_STRUCT( S2_storeMultipleStrings )
{
   DECLARE_STRING_STRUCT( S2_storeMultipleStrings, __STRINGTOSTORE );
   DECLARE_STRING_ARRAY( S2_storeMultipleStrings, __STOREDSTRINGS );
   DECLARE_INTARRAY( S2_storeMultipleStrings, __INPUTSTATE );
};



#endif //__S2_STOREMULTIPLESTRINGS_H__

