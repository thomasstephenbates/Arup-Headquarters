#ifndef __S2_BIAMP_AUDIAFLEX_COMMAND_PROCESSOR_V7_0_H__
#define __S2_BIAMP_AUDIAFLEX_COMMAND_PROCESSOR_V7_0_H__




/*
* Constructor and Destructor
*/

/*
* DIGITAL_INPUT
*/
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SEND_NEXT_DIG_INPUT 0
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_INITIALIZE_DIG_INPUT 1
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_GET_NEXT_NAME_DIG_INPUT 2


/*
* ANALOG_INPUT
*/


#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_FROM_DEVICE_BUFFER_INPUT 0
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_FROM_DEVICE_BUFFER_MAX_LEN 5000
CREATE_STRING_STRUCT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __FROM_DEVICE, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_FROM_DEVICE_BUFFER_MAX_LEN );
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_FROM_MODULES_BUFFER_INPUT 1
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_FROM_MODULES_BUFFER_MAX_LEN 3000
CREATE_STRING_STRUCT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __FROM_MODULES, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_FROM_MODULES_BUFFER_MAX_LEN );

#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_INSTANCE_ID_BUFFER_INPUT 2
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_INSTANCE_ID_ARRAY_NUM_ELEMS 500
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_INSTANCE_ID_ARRAY_NUM_CHARS 100
CREATE_STRING_ARRAY( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __INSTANCE_ID, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_INSTANCE_ID_ARRAY_NUM_ELEMS, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_INSTANCE_ID_ARRAY_NUM_CHARS );

/*
* DIGITAL_OUTPUT
*/
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_TIMED_OUT_DIG_OUTPUT 0
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_INITIALIZE_BUSY_DIG_OUTPUT 1
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_NAME_TIMED_OUT_DIG_OUTPUT 2


/*
* ANALOG_OUTPUT
*/

#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_TO_DEVICE$_STRING_OUTPUT 0

#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_TO_MODULES_STRING_OUTPUT 1
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_TO_MODULES_ARRAY_LENGTH 500

/*
* Direct Socket Variables
*/




/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* STRING_PARAMETER
*/


/*
* INTEGER
*/


/*
* LONG_INTEGER
*/


/*
* SIGNED_INTEGER
*/


/*
* SIGNED_LONG_INTEGER
*/


/*
* STRING
*/
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_STEMPMODULES_STRING_MAX_LEN 100
CREATE_STRING_STRUCT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __STEMPMODULES, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_STEMPMODULES_STRING_MAX_LEN );
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_STEMPDEVICE_STRING_MAX_LEN 100
CREATE_STRING_STRUCT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __STEMPDEVICE, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_STEMPDEVICE_STRING_MAX_LEN );
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SCOMMAND_ARRAY_NUM_ELEMS 100
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SCOMMAND_ARRAY_NUM_CHARS 100
CREATE_STRING_ARRAY( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __SCOMMAND, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SCOMMAND_ARRAY_NUM_ELEMS, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SCOMMAND_ARRAY_NUM_CHARS );
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SGET_ARRAY_NUM_ELEMS 100
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SGET_ARRAY_NUM_CHARS 100
CREATE_STRING_ARRAY( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __SGET, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SGET_ARRAY_NUM_ELEMS, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SGET_ARRAY_NUM_CHARS );
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SMODULEINSTANCEID_ARRAY_NUM_ELEMS 500
#define __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SMODULEINSTANCEID_ARRAY_NUM_CHARS 100
CREATE_STRING_ARRAY( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __SMODULEINSTANCEID, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SMODULEINSTANCEID_ARRAY_NUM_ELEMS, __S2_BiAmp_AudiaFlex_Command_Processor_v7_0_SMODULEINSTANCEID_ARRAY_NUM_CHARS );

/*
* STRUCTURE
*/

START_GLOBAL_VAR_STRUCT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0 )
{
   void* InstancePtr;
   struct GenericOutputString_s sGenericOutStr;
   unsigned short LastModifiedArrayIndex;

   DECLARE_IO_ARRAY( __TO_MODULES );
   unsigned short __INEXTCOMMANDSTORE;
   unsigned short __INEXTCOMMANDSEND;
   unsigned short __INEXTGETSTORE;
   unsigned short __INEXTGETSEND;
   unsigned short __BFLAG1;
   unsigned short __BFLAG2;
   unsigned short __BOKTOSEND;
   unsigned short __ITEMP;
   unsigned short __INUMOUTPUTS;
   unsigned short __A;
   unsigned short __B;
   unsigned short __ISENDNAME;
   unsigned short __INONAMERESP;
   DECLARE_STRING_STRUCT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __STEMPMODULES );
   DECLARE_STRING_STRUCT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __STEMPDEVICE );
   DECLARE_STRING_ARRAY( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __SCOMMAND );
   DECLARE_STRING_ARRAY( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __SGET );
   DECLARE_STRING_ARRAY( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __SMODULEINSTANCEID );
   DECLARE_STRING_STRUCT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __FROM_DEVICE );
   DECLARE_STRING_STRUCT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __FROM_MODULES );
   DECLARE_STRING_ARRAY( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, __INSTANCE_ID );
};

START_NVRAM_VAR_STRUCT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0 )
{
};

DEFINE_WAITEVENT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, WTIMEOUT );
DEFINE_WAITEVENT( S2_BiAmp_AudiaFlex_Command_Processor_v7_0, WNAMETIMEOUT );


#endif //__S2_BIAMP_AUDIAFLEX_COMMAND_PROCESSOR_V7_0_H__

