#ifndef __S2_ALARMCLOCKPROCESSOR_V1_0_H__
#define __S2_ALARMCLOCKPROCESSOR_V1_0_H__



/*
* STRUCTURE S2_AlarmClockProcessor_v1_0__ALARMSTORE
*/
#define ALARMSTORE__S2_AlarmClockProcessor_v1_0_S_ALARMTIME_STRING_MAX_LEN 15
#define ALARMSTORE__S2_AlarmClockProcessor_v1_0_S_AMPM_STRING_MAX_LEN 2
START_STRUCTURE_DEFINITION( S2_AlarmClockProcessor_v1_0, ALARMSTORE )
{
   CREATE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, ALARMSTORE__S_ALARMTIME, ALARMSTORE__S2_AlarmClockProcessor_v1_0_S_ALARMTIME_STRING_MAX_LEN );
   DECLARE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, ALARMSTORE__S_ALARMTIME );
   CREATE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, ALARMSTORE__S_AMPM, ALARMSTORE__S2_AlarmClockProcessor_v1_0_S_AMPM_STRING_MAX_LEN );
   DECLARE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, ALARMSTORE__S_AMPM );
   unsigned short ALARMSTORE__S_A_HOUR;
   unsigned short ALARMSTORE__S_A_HOURTEMP;
   unsigned short ALARMSTORE__S_A_MINUTE;
   unsigned short ALARMSTORE__S_A_SET;
   unsigned short ALARMSTORE__S_A_DAYS;
};


/*
* Constructor and Destructor
*/
int S2_AlarmClockProcessor_v1_0_ALARMSTORE_Constructor ( START_STRUCTURE_DEFINITION( S2_AlarmClockProcessor_v1_0, ALARMSTORE ) * me, int nVerbose );
int S2_AlarmClockProcessor_v1_0_ALARMSTORE_Destructor ( START_STRUCTURE_DEFINITION( S2_AlarmClockProcessor_v1_0, ALARMSTORE ) * me, int nVerbose );

/*
* DIGITAL_INPUT
*/
#define __S2_AlarmClockProcessor_v1_0_ALARM_UPDATE_DIG_INPUT 0
#define __S2_AlarmClockProcessor_v1_0_ALARM_ON_DIG_INPUT 1
#define __S2_AlarmClockProcessor_v1_0_ALARM_OFF_DIG_INPUT 2
#define __S2_AlarmClockProcessor_v1_0_HOUR_UP_DIG_INPUT 3
#define __S2_AlarmClockProcessor_v1_0_HOUR_DOWN_DIG_INPUT 4
#define __S2_AlarmClockProcessor_v1_0_MINUTE_UP_DIG_INPUT 5
#define __S2_AlarmClockProcessor_v1_0_MINUTE_DOWN_DIG_INPUT 6
#define __S2_AlarmClockProcessor_v1_0_ALARM_1_DIG_INPUT 7
#define __S2_AlarmClockProcessor_v1_0_ALARM_2_DIG_INPUT 8
#define __S2_AlarmClockProcessor_v1_0_ALARM_SUNDAY_DIG_INPUT 9
#define __S2_AlarmClockProcessor_v1_0_ALARM_MONDAY_DIG_INPUT 10
#define __S2_AlarmClockProcessor_v1_0_ALARM_TUESDAY_DIG_INPUT 11
#define __S2_AlarmClockProcessor_v1_0_ALARM_WEDNESDAY_DIG_INPUT 12
#define __S2_AlarmClockProcessor_v1_0_ALARM_THURSDAY_DIG_INPUT 13
#define __S2_AlarmClockProcessor_v1_0_ALARM_FRIDAY_DIG_INPUT 14
#define __S2_AlarmClockProcessor_v1_0_ALARM_SATURDAY_DIG_INPUT 15
#define __S2_AlarmClockProcessor_v1_0_SNOOZE_DIG_INPUT 16
#define __S2_AlarmClockProcessor_v1_0_RESET_DIG_INPUT 17


/*
* ANALOG_INPUT
*/
#define __S2_AlarmClockProcessor_v1_0_SNOOZE_TIME_1_ANALOG_INPUT 0
#define __S2_AlarmClockProcessor_v1_0_SNOOZE_TIME_2_ANALOG_INPUT 1
#define __S2_AlarmClockProcessor_v1_0_DURATION_TIME_ANALOG_INPUT 2

#define __S2_AlarmClockProcessor_v1_0_FILENAME_STRING_INPUT 3
#define __S2_AlarmClockProcessor_v1_0_FILENAME_STRING_MAX_LEN 50
CREATE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, __FILENAME, __S2_AlarmClockProcessor_v1_0_FILENAME_STRING_MAX_LEN );



/*
* DIGITAL_OUTPUT
*/
#define __S2_AlarmClockProcessor_v1_0_ALARM_ON_FB_DIG_OUTPUT 0
#define __S2_AlarmClockProcessor_v1_0_ALARM_OFF_FB_DIG_OUTPUT 1
#define __S2_AlarmClockProcessor_v1_0_ALARM_1_FB_DIG_OUTPUT 2
#define __S2_AlarmClockProcessor_v1_0_ALARM_1_ACTIVE_FB_DIG_OUTPUT 3
#define __S2_AlarmClockProcessor_v1_0_ALARM_1_ACTION_ON_FB_DIG_OUTPUT 4
#define __S2_AlarmClockProcessor_v1_0_ALARM_1_ACTION_OFF_FB_DIG_OUTPUT 5
#define __S2_AlarmClockProcessor_v1_0_ALARM_2_FB_DIG_OUTPUT 6
#define __S2_AlarmClockProcessor_v1_0_ALARM_2_ACTIVE_FB_DIG_OUTPUT 7
#define __S2_AlarmClockProcessor_v1_0_ALARM_2_ACTION_ON_FB_DIG_OUTPUT 8
#define __S2_AlarmClockProcessor_v1_0_ALARM_2_ACTION_OFF_FB_DIG_OUTPUT 9
#define __S2_AlarmClockProcessor_v1_0_SNOOZE_ACTIVE_FB_DIG_OUTPUT 10
#define __S2_AlarmClockProcessor_v1_0_ALARM_SUB_DIG_OUTPUT 11


/*
* ANALOG_OUTPUT
*/
#define __S2_AlarmClockProcessor_v1_0_ALARM_DAY_FB_ANALOG_OUTPUT 0

#define __S2_AlarmClockProcessor_v1_0_C_TIME_STRING_OUTPUT 1
#define __S2_AlarmClockProcessor_v1_0_ALARM_TIME_STRING_OUTPUT 2

#define __S2_AlarmClockProcessor_v1_0_ALARM_SET_TIME_STRING_OUTPUT 3
#define __S2_AlarmClockProcessor_v1_0_ALARM_SET_TIME_ARRAY_LENGTH 2

/*
* Direct Socket Variables
*/




/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* STRING_PARAMETER
*/


/*
* INTEGER
*/
CREATE_INTARRAY1D( S2_AlarmClockProcessor_v1_0, __A_HOUR, 8 );;
CREATE_INTARRAY1D( S2_AlarmClockProcessor_v1_0, __A_HOURTEMP, 8 );;
CREATE_INTARRAY1D( S2_AlarmClockProcessor_v1_0, __A_MINUTE, 8 );;
CREATE_INTARRAY1D( S2_AlarmClockProcessor_v1_0, __A_DAYS, 8 );;
CREATE_INTARRAY1D( S2_AlarmClockProcessor_v1_0, __SNOOZED, 2 );;
CREATE_INTARRAY1D( S2_AlarmClockProcessor_v1_0, __DAY_ACTIVE, 2 );;
CREATE_INTARRAY1D( S2_AlarmClockProcessor_v1_0, __DURATION_ON, 2 );;


/*
* LONG_INTEGER
*/


/*
* SIGNED_INTEGER
*/


/*
* SIGNED_LONG_INTEGER
*/


/*
* STRING
*/
#define __S2_AlarmClockProcessor_v1_0_DURATIONTIME_STRING_MAX_LEN 2
CREATE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, __DURATIONTIME, __S2_AlarmClockProcessor_v1_0_DURATIONTIME_STRING_MAX_LEN );
#define __S2_AlarmClockProcessor_v1_0_DURATION_AM_PM_STRING_MAX_LEN 2
CREATE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, __DURATION_AM_PM, __S2_AlarmClockProcessor_v1_0_DURATION_AM_PM_STRING_MAX_LEN );
#define __S2_AlarmClockProcessor_v1_0_CURRENTIME_STRING_MAX_LEN 15
CREATE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, __CURRENTIME, __S2_AlarmClockProcessor_v1_0_CURRENTIME_STRING_MAX_LEN );
#define __S2_AlarmClockProcessor_v1_0_ALARMTIME_ARRAY_NUM_ELEMS 4
#define __S2_AlarmClockProcessor_v1_0_ALARMTIME_ARRAY_NUM_CHARS 15
CREATE_STRING_ARRAY( S2_AlarmClockProcessor_v1_0, __ALARMTIME, __S2_AlarmClockProcessor_v1_0_ALARMTIME_ARRAY_NUM_ELEMS, __S2_AlarmClockProcessor_v1_0_ALARMTIME_ARRAY_NUM_CHARS );
#define __S2_AlarmClockProcessor_v1_0_AMPM_ARRAY_NUM_ELEMS 8
#define __S2_AlarmClockProcessor_v1_0_AMPM_ARRAY_NUM_CHARS 2
CREATE_STRING_ARRAY( S2_AlarmClockProcessor_v1_0, __AMPM, __S2_AlarmClockProcessor_v1_0_AMPM_ARRAY_NUM_ELEMS, __S2_AlarmClockProcessor_v1_0_AMPM_ARRAY_NUM_CHARS );
#define __S2_AlarmClockProcessor_v1_0_SNOOZEALARM_ARRAY_NUM_ELEMS 2
#define __S2_AlarmClockProcessor_v1_0_SNOOZEALARM_ARRAY_NUM_CHARS 15
CREATE_STRING_ARRAY( S2_AlarmClockProcessor_v1_0, __SNOOZEALARM, __S2_AlarmClockProcessor_v1_0_SNOOZEALARM_ARRAY_NUM_ELEMS, __S2_AlarmClockProcessor_v1_0_SNOOZEALARM_ARRAY_NUM_CHARS );
#define __S2_AlarmClockProcessor_v1_0_DURATION_OFF_TIME_ARRAY_NUM_ELEMS 2
#define __S2_AlarmClockProcessor_v1_0_DURATION_OFF_TIME_ARRAY_NUM_CHARS 15
CREATE_STRING_ARRAY( S2_AlarmClockProcessor_v1_0, __DURATION_OFF_TIME, __S2_AlarmClockProcessor_v1_0_DURATION_OFF_TIME_ARRAY_NUM_ELEMS, __S2_AlarmClockProcessor_v1_0_DURATION_OFF_TIME_ARRAY_NUM_CHARS );

/*
* STRUCTURE
*/
#define __S2_AlarmClockProcessor_v1_0_S_ALARM_STRUCT_MAX_LEN 2
CREATE_STRUCTURE_ARRAY( S2_AlarmClockProcessor_v1_0, __S_ALARM, ALARMSTORE, __S2_AlarmClockProcessor_v1_0_S_ALARM_STRUCT_MAX_LEN );

START_GLOBAL_VAR_STRUCT( S2_AlarmClockProcessor_v1_0 )
{
   void* InstancePtr;
   struct GenericOutputString_s sGenericOutStr;
   unsigned short LastModifiedArrayIndex;

   DECLARE_IO_ARRAY( __ALARM_SET_TIME );
   unsigned short __NUMHOURS;
   unsigned short __NUMMINUTES;
   unsigned short __NUMSECONDS;
   unsigned short __CURRENTALARMSELECT;
   unsigned short __ICOUNT;
   unsigned short __ALARM_RESET_OFF;
   unsigned short __SNOOZE_VAL;
   unsigned short __SNOOZECOUNT;
   unsigned short __SNOOZEHR;
   unsigned short __SNOOZEAL;
   unsigned short __DURATION_VAL;
   unsigned short __DURATION_HOUR;
   unsigned short __DURATION_MINUTE;
   unsigned short __LASTALARM;
   DECLARE_INTARRAY( S2_AlarmClockProcessor_v1_0, __A_HOUR );
   DECLARE_INTARRAY( S2_AlarmClockProcessor_v1_0, __A_HOURTEMP );
   DECLARE_INTARRAY( S2_AlarmClockProcessor_v1_0, __A_MINUTE );
   DECLARE_INTARRAY( S2_AlarmClockProcessor_v1_0, __A_DAYS );
   DECLARE_INTARRAY( S2_AlarmClockProcessor_v1_0, __SNOOZED );
   DECLARE_INTARRAY( S2_AlarmClockProcessor_v1_0, __DAY_ACTIVE );
   DECLARE_INTARRAY( S2_AlarmClockProcessor_v1_0, __DURATION_ON );
   DECLARE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, __DURATIONTIME );
   DECLARE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, __DURATION_AM_PM );
   DECLARE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, __CURRENTIME );
   DECLARE_STRING_ARRAY( S2_AlarmClockProcessor_v1_0, __ALARMTIME );
   DECLARE_STRING_ARRAY( S2_AlarmClockProcessor_v1_0, __AMPM );
   DECLARE_STRING_ARRAY( S2_AlarmClockProcessor_v1_0, __SNOOZEALARM );
   DECLARE_STRING_ARRAY( S2_AlarmClockProcessor_v1_0, __DURATION_OFF_TIME );
   DECLARE_STRING_STRUCT( S2_AlarmClockProcessor_v1_0, __FILENAME );
   DECLARE_STRUCT_ARRAY( S2_AlarmClockProcessor_v1_0, __S_ALARM );
};

START_NVRAM_VAR_STRUCT( S2_AlarmClockProcessor_v1_0 )
{
};



#endif //__S2_ALARMCLOCKPROCESSOR_V1_0_H__

