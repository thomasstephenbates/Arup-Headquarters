#ifndef __S2_BIAMP_AUDIAFLEX_DIALER_PROCESSOR_V7_0_H__
#define __S2_BIAMP_AUDIAFLEX_DIALER_PROCESSOR_V7_0_H__




/*
* Constructor and Destructor
*/

/*
* DIGITAL_INPUT
*/
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_ON_HOOK_DIG_INPUT 0
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_OFF_HOOK_DIG_INPUT 1
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_KEYBOARDGO_DIG_INPUT 2
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_CLEAR_DIG_INPUT 3
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_BACK_DIG_INPUT 4
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_DIAL_DIG_INPUT 5
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_REDIAL_DIG_INPUT 6
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_CLEAR_LAST__LB___DIALED_DIG_INPUT 7
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_PRESET_STORE_DIG_INPUT 8
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_GET_NAMES_DIG_INPUT 9
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_FIRST_DIG_INPUT 10
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SCROLL_UP_DIG_INPUT 11
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SCROLL_DOWN_DIG_INPUT 12
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_POLL_DIG_INPUT 13

#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_DIAL_ENTRY_DIG_INPUT 14
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_DIAL_ENTRY_ARRAY_LENGTH 16
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_PRESETS_DIG_INPUT 30
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_PRESETS_ARRAY_LENGTH 16

/*
* ANALOG_INPUT
*/
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_MAXCHARACTERS_ANALOG_INPUT 0
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_KEYBOARDAN_ANALOG_INPUT 1
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_APRESET_ANALOG_INPUT 2
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_ENTRIES_PER_PAGE_ANALOG_INPUT 3

#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_HEADER$_STRING_INPUT 4
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_HEADER$_STRING_MAX_LEN 50
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __HEADER$, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_HEADER$_STRING_MAX_LEN );
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_ADDRESS$_STRING_INPUT 5
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_ADDRESS$_STRING_MAX_LEN 5
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __ADDRESS$, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_ADDRESS$_STRING_MAX_LEN );
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_INSTANCE$_STRING_INPUT 6
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_INSTANCE$_STRING_MAX_LEN 50
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __INSTANCE$, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_INSTANCE$_STRING_MAX_LEN );

#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_FROM_SMPL$_BUFFER_INPUT 7
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_FROM_SMPL$_BUFFER_MAX_LEN 100
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __FROM_SMPL$, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_FROM_SMPL$_BUFFER_MAX_LEN );


/*
* DIGITAL_OUTPUT
*/
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_ON_HOOK_FB_DIG_OUTPUT 0
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_OFF_HOOK_FB_DIG_OUTPUT 1


/*
* ANALOG_OUTPUT
*/

#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_PHONE_NUMBER$_STRING_OUTPUT 0
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_TO_DEVICE$_STRING_OUTPUT 1
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_INSTANCE_ID_OUT_STRING_OUTPUT 2

#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_ENTRY_NAME$_STRING_OUTPUT 3
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_ENTRY_NAME$_ARRAY_LENGTH 16

/*
* Direct Socket Variables
*/




/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* STRING_PARAMETER
*/


/*
* INTEGER
*/
CREATE_INTARRAY1D( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __IDISPLAYENTRYNUMBER, 16 );;


/*
* LONG_INTEGER
*/


/*
* SIGNED_INTEGER
*/


/*
* SIGNED_LONG_INTEGER
*/


/*
* STRING
*/
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_TEMPDIAL$_STRING_MAX_LEN 100
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __TEMPDIAL$, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_TEMPDIAL$_STRING_MAX_LEN );
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SHEADER_STRING_MAX_LEN 50
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SHEADER, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SHEADER_STRING_MAX_LEN );
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_NUM$_STRING_MAX_LEN 50
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __NUM$, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_NUM$_STRING_MAX_LEN );
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SNUM2_STRING_MAX_LEN 10
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SNUM2, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SNUM2_STRING_MAX_LEN );
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_LAST_NUM_DIALED$_STRING_MAX_LEN 50
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __LAST_NUM_DIALED$, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_LAST_NUM_DIALED$_STRING_MAX_LEN );
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SLABELCOMPARE$_STRING_MAX_LEN 40
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SLABELCOMPARE$, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SLABELCOMPARE$_STRING_MAX_LEN );
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SHOOKSTATECOMPARE$_STRING_MAX_LEN 40
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SHOOKSTATECOMPARE$, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SHOOKSTATECOMPARE$_STRING_MAX_LEN );
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SINSTANCE_STRING_MAX_LEN 52
CREATE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SINSTANCE, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SINSTANCE_STRING_MAX_LEN );
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_PRESET_RAM_ARRAY_NUM_ELEMS 16
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_PRESET_RAM_ARRAY_NUM_CHARS 40
CREATE_STRING_ARRAY( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __PRESET_RAM, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_PRESET_RAM_ARRAY_NUM_ELEMS, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_PRESET_RAM_ARRAY_NUM_CHARS );
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SENTRYNAME_ARRAY_NUM_ELEMS 16
#define __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SENTRYNAME_ARRAY_NUM_CHARS 40
CREATE_STRING_ARRAY( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SENTRYNAME, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SENTRYNAME_ARRAY_NUM_ELEMS, __S2_Biamp_AudiaFlex_Dialer_Processor_v7_0_SENTRYNAME_ARRAY_NUM_CHARS );

/*
* STRUCTURE
*/

START_GLOBAL_VAR_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0 )
{
   void* InstancePtr;
   struct GenericOutputString_s sGenericOutStr;
   unsigned short LastModifiedArrayIndex;

   DECLARE_IO_ARRAY( __DIAL_ENTRY );
   DECLARE_IO_ARRAY( __PRESETS );
   DECLARE_IO_ARRAY( __ENTRY_NAME$ );
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __HEADER$ );
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __ADDRESS$ );
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __INSTANCE$ );
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __FROM_SMPL$ );
};

START_NVRAM_VAR_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0 )
{
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __TEMPDIAL$ );
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SHEADER );
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __NUM$ );
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SNUM2 );
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __LAST_NUM_DIALED$ );
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SLABELCOMPARE$ );
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SHOOKSTATECOMPARE$ );
   DECLARE_STRING_STRUCT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SINSTANCE );
   DECLARE_STRING_ARRAY( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __PRESET_RAM );
   DECLARE_STRING_ARRAY( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SENTRYNAME );
   unsigned short __IMAXCHARS;
   unsigned short __IPRESET;
   unsigned short __SEMAPHORE;
   unsigned short __IHOOK;
   unsigned short __IENTRIESPERPAGE;
   unsigned short __IOFFSET;
   DECLARE_INTARRAY( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __IDISPLAYENTRYNUMBER );
};

DEFINE_WAITEVENT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SPLS_TMPVAR__WAITLABEL_0__ );
DEFINE_WAITEVENT( S2_Biamp_AudiaFlex_Dialer_Processor_v7_0, __SPLS_TMPVAR__WAITLABEL_1__ );


#endif //__S2_BIAMP_AUDIAFLEX_DIALER_PROCESSOR_V7_0_H__

