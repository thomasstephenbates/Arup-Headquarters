#ifndef __S2_DIALING_KEYPAD__H__
#define __S2_DIALING_KEYPAD__H__




/*
* Constructor and Destructor
*/

/*
* DIGITAL_INPUT
*/
#define __S2_dialing_keypad__BACKSPACE_DIG_INPUT 0
#define __S2_dialing_keypad__CLEAR_DIG_INPUT 1
#define __S2_dialing_keypad__ENABLE_DIG_INPUT 2
#define __S2_dialing_keypad__RESEND_DIG_INPUT 3

#define __S2_dialing_keypad__KEY_DIG_INPUT 4
#define __S2_dialing_keypad__KEY_ARRAY_LENGTH 13

/*
* ANALOG_INPUT
*/




/*
* DIGITAL_OUTPUT
*/


/*
* ANALOG_OUTPUT
*/

#define __S2_dialing_keypad__NUMBER$_STRING_OUTPUT 0


/*
* Direct Socket Variables
*/




/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* INTEGER_PARAMETER
*/
/*
* SIGNED_INTEGER_PARAMETER
*/
/*
* LONG_INTEGER_PARAMETER
*/
/*
* SIGNED_LONG_INTEGER_PARAMETER
*/
/*
* STRING_PARAMETER
*/


/*
* INTEGER
*/


/*
* LONG_INTEGER
*/


/*
* SIGNED_INTEGER
*/


/*
* SIGNED_LONG_INTEGER
*/


/*
* STRING
*/
#define __S2_dialing_keypad__DIALINGSTRINGS_STRING_MAX_LEN 15
CREATE_STRING_STRUCT( S2_dialing_keypad_, __DIALINGSTRINGS, __S2_dialing_keypad__DIALINGSTRINGS_STRING_MAX_LEN );
#define __S2_dialing_keypad__CURRENTSTRING_STRING_MAX_LEN 100
CREATE_STRING_STRUCT( S2_dialing_keypad_, __CURRENTSTRING, __S2_dialing_keypad__CURRENTSTRING_STRING_MAX_LEN );

/*
* STRUCTURE
*/

START_GLOBAL_VAR_STRUCT( S2_dialing_keypad_ )
{
   void* InstancePtr;
   struct GenericOutputString_s sGenericOutStr;
   unsigned short LastModifiedArrayIndex;

   DECLARE_IO_ARRAY( __KEY );
   DECLARE_STRING_STRUCT( S2_dialing_keypad_, __DIALINGSTRINGS );
   DECLARE_STRING_STRUCT( S2_dialing_keypad_, __CURRENTSTRING );
};

START_NVRAM_VAR_STRUCT( S2_dialing_keypad_ )
{
};



#endif //__S2_DIALING_KEYPAD__H__

